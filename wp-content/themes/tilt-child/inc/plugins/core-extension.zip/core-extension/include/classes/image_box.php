<?php
class WPBakeryShortCode_VC_Image_Box extends WPBakeryShortCode
{

}