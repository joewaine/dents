<?php
class WPBakeryShortCode_VC_Image_Gallery extends WPBakeryShortCode {

}