<?php
class WPBakeryShortCode_VC_Info_Box extends WPBakeryShortCode
{
	public function singleParamHtmlHolder( $param, $value )
	{
		return '';
	}
}