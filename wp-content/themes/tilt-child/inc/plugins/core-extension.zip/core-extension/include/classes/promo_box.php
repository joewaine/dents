<?php
class WPBakeryShortCode_VC_Promo_Box extends WPBakeryShortCode {

}