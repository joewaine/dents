<?php

class WPBakeryShortCode_VC_Slider_Carousel extends WPBakeryShortCode {
	public function outputTitle($title) {
		return '';
	}
}